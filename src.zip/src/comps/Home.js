import Navbar from "./Navbar";
import Map from "./Map";
import Pricing from "./Pricing";
import '../Css/Home.css';
import Cafe from "./Cafe";
import Nav2 from "./Nav2";
import Adv from "./Adv";
import Step from "./Step";

const Home = () => {
    return (
        <div className="homepage">
      <header className="homepage-header">
       {/* <Nav2></Nav2> */}
       <Navbar></Navbar>
        <p className='p1'>Your reliable partner for electric vehicle charging solutions.</p>
      </header>
        <Map></Map>

      <section className="features">
        <div className="feature">
          <Adv></Adv>
        </div>
        <div className="feature">
        <Pricing></Pricing>
        </div>
        <div className="feature">
          <Step></Step>
          
        </div>
        <div className="feature">
          <Cafe></Cafe>
        </div>
      </section>
      <footer className="homepage-footer">
        <p>&copy; 2024 EV Charging. All rights reserved.</p>
      </footer>

      {/* <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/find-stations" element={<FindStations />} />
          <Route path="/plan-route" element={<PlanRoute />} />
          <Route path="/monitor-charging" element={<MonitorCharging />} />
        </Routes> */}
    </div>
    );
}
 
export default Home;