// src/pages/LoginPage.js
import React, { useState } from 'react';
import '../Css/Login.css';
import Navbar from './Navbar';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    role: 'Car Owner'
  });

  const [errors, setErrors] = useState({});
  const [submissionStatus, setSubmissionStatus] = useState('');

  const validateForm = () => {
    const newErrors = {};
    if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email))
      newErrors.email = 'Valid email is required';
    if (!formData.password || formData.password.length < 6)
      newErrors.password = 'Password must be at least 6 characters';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validateForm()) {
      setSubmissionStatus('Logging in...');
      
      try {
        const response = await fetch('https://api.mockserver.com/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(formData)
        });

        if (response.ok) {
          setSubmissionStatus('Login successful!');
          setFormData({
            email: '',
            password: '',
            role: 'Car Owner'
          });
          setErrors({});
        } else {
          setSubmissionStatus('Login failed. Please try again.');
        }
      } catch (error) {
        setSubmissionStatus('Error submitting the form. Please try again.');
      }
    }
  };

  return (
    <div>
        <Navbar></Navbar>
    <div className="login-form-wrapper">
      <div className="login-form-container">
        <h1>Login</h1>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className={errors.email ? 'error' : ''}
            />
            {errors.email && <span className="error-text">{errors.email}</span>}
          </div>
          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              className={errors.password ? 'error' : ''}
            />
            {errors.password && <span className="error-text">{errors.password}</span>}
          </div>
          <div className="form-group">
            <label>Role</label>
            <select
              name="role"
              value={formData.role}
              onChange={handleChange}
              className={errors.role ? 'error' : ''}
            >
              <option value="Car Owner">Car Owner</option>
              <option value="Station Owner">Station Owner</option>
            </select>
          </div>
          <button type="submit">Login</button>
        </form>
        {submissionStatus && <p className="submission-status">{submissionStatus}</p>}
      </div>
    </div>
    <footer className="footer">
        <p>&copy; 2024 EV Charging. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Login;
