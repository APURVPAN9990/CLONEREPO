// src/pages/RegistrationForm.js
import React, { useState } from 'react';
import '../Css/Registration.css';
import Navbar from './Navbar';

const Registration = () => {
  const [formData, setFormData] = useState({
    name: '',
    contactNumber: '',
    email: '',
    password: '',
    vehicleCompany: '',
    model: '',
    vehicleNumber: '',
    batteryMah: '',
    fullAddress: '',
    role: 'Car Owner'
  });

  const [errors, setErrors] = useState({});
  const [submissionStatus, setSubmissionStatus] = useState('');

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name) newErrors.name = 'Name is required';
    if (!formData.contactNumber || !/^\d{10}$/.test(formData.contactNumber))
      newErrors.contactNumber = 'Valid 10-digit contact number is required';
    if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email))
      newErrors.email = 'Valid email is required';
    if (!formData.password || formData.password.length < 6)
      newErrors.password = 'Password must be at least 6 characters';
    if (!formData.vehicleCompany) newErrors.vehicleCompany = 'Vehicle company is required';
    if (!formData.model) newErrors.model = 'Model is required';
    if (!formData.vehicleNumber) newErrors.vehicleNumber = 'Vehicle number is required';
    if (!formData.batteryMah || isNaN(formData.batteryMah))
      newErrors.batteryMah = 'Valid Battery mAh is required';
    if (!formData.fullAddress) newErrors.fullAddress = 'Full address is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validateForm()) {
      setSubmissionStatus('Submitting...');
      
      try {
        // Mock API call
        const response = await fetch('https://api.mockserver.com/register', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(formData)
        });

        if (response.ok) {
          setSubmissionStatus('Registration successful!');
          // Reset the form
          setFormData({
            name: '',
            contactNumber: '',
            email: '',
            password: '',
            vehicleCompany: '',
            model: '',
            vehicleNumber: '',
            
            fullAddress: '',
            
          });
          setErrors({});
        } else {
          setSubmissionStatus('Registration failed. Please try again.');
        }
      } catch (error) {
        setSubmissionStatus('Error submitting the form. Please try again.');
      }
    }
  };

  return (
    <div className='backgound'>
        <Navbar></Navbar>
    <div className="registration-form-container">
      <h1>Register</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className={errors.name ? 'error' : ''}
          />
          {errors.name && <span className="error-text">{errors.name}</span>}
        </div>
        <div className="form-group">
          <label>Contact Number</label>
          <input
            type="text"
            name="contactNumber"
            value={formData.contactNumber}
            onChange={handleChange}
            className={errors.contactNumber ? 'error' : ''}
          />
          {errors.contactNumber && <span className="error-text">{errors.contactNumber}</span>}
        </div>
        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className={errors.email ? 'error' : ''}
          />
          {errors.email && <span className="error-text">{errors.email}</span>}
        </div>
        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            className={errors.password ? 'error' : ''}
          />
          {errors.password && <span className="error-text">{errors.password}</span>}
        </div>
        <div className="form-group">
          <label>Vehicle Company</label>
          <input
            type="text"
            name="vehicleCompany"
            value={formData.vehicleCompany}
            onChange={handleChange}
            className={errors.vehicleCompany ? 'error' : ''}
          />
          {errors.vehicleCompany && <span className="error-text">{errors.vehicleCompany}</span>}
        </div>
        <div className="form-group">
          <label>Model</label>
          <input
            type="text"
            name="model"
            value={formData.model}
            onChange={handleChange}
            className={errors.model ? 'error' : ''}
          />
          {errors.model && <span className="error-text">{errors.model}</span>}
        </div>
        <div className="form-group">
          <label>Vehicle Number</label>
          <input
            type="text"
            name="vehicleNumber"
            value={formData.vehicleNumber}
            onChange={handleChange}
            className={errors.vehicleNumber ? 'error' : ''}
          />
          {errors.vehicleNumber && <span className="error-text">{errors.vehicleNumber}</span>}
        </div>
        <div className="form-group">
          <label>Full Address</label>
          <textarea
            name="fullAddress"
            value={formData.fullAddress}
            onChange={handleChange}
            className={errors.fullAddress ? 'error' : ''}
          ></textarea>
          {errors.fullAddress && <span className="error-text">{errors.fullAddress}</span>}
        </div>
        <div className="form-group">
          <label>Role</label>
          <select
            name="role"
            value={formData.role}
            onChange={handleChange}
          >
            <option value="Car Owner">Car Owner</option>
          </select>
        </div>
        <button type="submit">Register</button>
        {submissionStatus && <p className="submission-status">{submissionStatus}</p>}
      </form>
    </div>
    <footer className="footer">
        <p>&copy; 2024 EV Charging. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Registration;
