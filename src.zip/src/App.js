//import logo from './logo.svg';
import "bootstrap/dist/css/bootstrap.min.css";
import './App.css';
//import Navbar from './comps/Navbar';
import Home from './comps/Home';
//import Boom from "./comps/Boom";
import Login from "./comps/Login";
import Registration from "./comps/Registration";
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Pricing from "./comps/Pricing";
import Cafe from "./comps/Cafe";
import Features from "./comps/Features";
import PaymentPage from "./comps/PaymentPage";
import SignUp from "./comps/SignUp";
import StationRegister from "./comps/StationRegister";

function App() {
  return (
    //<Home></Home>
    //<Login></Login>
    //<Registration></Registration>
    //<Boom></Boom>
    //<Navbar></Navbar>
    
    <div>
    <Router>
      <div>
        
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Registration />} />
          <Route path="/stationregister" element={<StationRegister/>} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/cafes" element={<Cafe />} />
          <Route path="/features" element={<Features/>}/>
          <Route path="/payment" element={<PaymentPage />} />
          <Route path="/signUp" element={<SignUp />} />
        </Routes>
      </div>
    </Router>
    </div>
  );
}

export default App;
