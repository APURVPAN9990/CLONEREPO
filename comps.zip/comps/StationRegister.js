// src/components/StationRegistrationForm.js
import React, { useState } from 'react';
import '../Css/StationRegister.css';
import Navbar from './Navbar';

const StationRegister = () => {
  const [formData, setFormData] = useState({
    ownerName: '',
    stationName: '',
    fullAddress: '',
    latitude: '',
    longitude: '',
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const validate = () => {
    let tempErrors = {};
    let isValid = true;

    if (!formData.ownerName) {
      tempErrors["ownerName"] = "Station owner's name is required.";
      isValid = false;
    }

    if (!formData.stationName) {
      tempErrors["stationName"] = "Station's name is required.";
      isValid = false;
    }

    if (!formData.fullAddress) {
      tempErrors["fullAddress"] = "Full address is required.";
      isValid = false;
    }

    if (!formData.latitude) {
      tempErrors["latitude"] = "Latitude is required.";
      isValid = false;
    }

    if (!formData.longitude) {
      tempErrors["longitude"] = "Longitude is required.";
      isValid = false;
    }

    setErrors(tempErrors);
    return isValid;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (validate()) {
      console.log("Form submitted:", formData);
      // Submit form logic here (e.g., API call)

      // Clear form after submission
      setFormData({
        ownerName: '',
        stationName: '',
        fullAddress: '',
        latitude: '',
        longitude: '',
      });
      setErrors({});
    }
  };

  return (
    <div>
      <Navbar></Navbar>
    <div className="station-registration-form-container">
      <h2>Charging Station Registration</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Station Owner's Name:</label>
          <input
            type="text"
            name="ownerName"
            value={formData.ownerName}
            onChange={handleChange}
          />
          {errors.ownerName && <span className="error">{errors.ownerName}</span>}
        </div>

        <div className="form-group">
          <label>Station's Name:</label>
          <input
            type="text"
            name="stationName"
            value={formData.stationName}
            onChange={handleChange}
          />
          {errors.stationName && <span className="error">{errors.stationName}</span>}
        </div>

        <div className="form-group">
          <label>Full Address:</label>
          <input
            type="text"
            name="fullAddress"
            value={formData.fullAddress}
            onChange={handleChange}
          />
          {errors.fullAddress && <span className="error">{errors.fullAddress}</span>}
        </div>

        <div className="form-group">
          <label>Latitude:</label>
          <input
            type="text"
            name="latitude"
            value={formData.latitude}
            onChange={handleChange}
          />
          {errors.latitude && <span className="error">{errors.latitude}</span>}
        </div>

        <div className="form-group">
          <label>Longitude:</label>
          <input
            type="text"
            name="longitude"
            value={formData.longitude}
            onChange={handleChange}
          />
          {errors.longitude && <span className="error">{errors.longitude}</span>}
        </div>

        <button type="submit">Register Station</button>
      </form>
    </div>
    </div>
  );
};

export default StationRegister;
