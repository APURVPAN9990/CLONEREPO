import Navbar from "./Navbar";
import '../Css/Home.css';
import { useNavigate } from 'react-router-dom';

const SignUp = () => {
  const navigate = useNavigate();

  const goToResgister = () => {
    navigate('/register');
  };

  const goToStationRegister = () => {
    navigate('/stationregister');
  };
    return (

      <div>
      
    
        <Navbar></Navbar>
      <section className="features">
        <button onClick={goToResgister}>User Registration</button>
        <button onClick={goToStationRegister}>Station Registration</button>
      </section>
      
    </div>
    );
}
 
export default SignUp;