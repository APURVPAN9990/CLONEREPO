// src/components/BookingInfo.js
import React from 'react';
import Adv from './Adv';
import Navbar from './Navbar';
import Pricing from './Pricing';
import Step from './Step';
import Cafe from './Cafe';
import '../Css/Features.css';

const Features = () => {
  return (
    <div className='div_out'>
        <Navbar></Navbar>
        <div className='div_int'>
        <Adv></Adv>
        <Pricing></Pricing>
        <Step></Step>
        <Cafe></Cafe>
        </div>
    </div>
  );
};

export default Features;
