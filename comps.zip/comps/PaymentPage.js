import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const PaymentPage = () => {
  const [paymentStatus, setPaymentStatus] = useState(false);
  const navigate = useNavigate();

  const handlePayment = () => {
    // Implement your payment logic here.
    // For now, we'll simulate a successful payment.
    setPaymentStatus(true);

    // Redirect to the directions page after payment
    navigate('/directions');
  };

  return (
    <div>
      {!paymentStatus ? (
        <div>
          <h3>Complete your payment to access directions</h3>
          <button onClick={handlePayment}>Pay Now</button>
        </div>
      ) : (
        <h3>Payment Successful! Redirecting to directions...</h3>
      )}
    </div>
  );
};

export default PaymentPage;
