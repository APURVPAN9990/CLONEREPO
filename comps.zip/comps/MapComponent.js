import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
/* global google */

const MapComponent = ({ chargingStations, onStationSelect, currentLocation, selectedStation }) => {
  const navigate = useNavigate();

  useEffect(() => {
    if (currentLocation) {
      // Initialize the map centered at the user's current location
      const map = new google.maps.Map(document.getElementById('map'), {
        center: currentLocation,
        zoom: 14,
      });

      // Define a custom icon for the current location marker
      const currentLocationIcon = {
        url: 'https://c7.alamy.com/comp/2GJ6JKY/car-symbols-frontal-car-icons-2GJ6JKY.jpg', // Replace with the URL of your custom icon
        scaledSize: new google.maps.Size(32, 32), // Adjust the size of the icon
        origin: new google.maps.Point(0, 0), // Origin of the icon
        anchor: new google.maps.Point(16, 32), // Anchor point (bottom center)
      };

      // Add a marker for the current location
      new google.maps.Marker({
        position: currentLocation,
        map: map,
        title: 'Your Location',
        icon: currentLocationIcon, // Use the custom icon for current location
      });

      // Create a LatLngBounds object
      const bounds = new google.maps.LatLngBounds();

      // Extend bounds to include the current location
      bounds.extend(currentLocation);

      // Add markers for each charging station and extend the bounds
      chargingStations.forEach(station => {
        const marker = new google.maps.Marker({
          position: { lat: station.lat, lng: station.lng },
          map: map,
          title: station.name,
        });

        // Extend the map bounds to include this station's location
        bounds.extend(marker.position);

        // Add click listener to select a station
        marker.addListener('click', () => {
          onStationSelect(station);
        });
      });

      // Ensure the map fits all markers
      map.fitBounds(bounds);
    }
  }, [currentLocation, chargingStations, onStationSelect],);

  const handlePaymentClick = () => {
    navigate('/payment');
  };

  return (
    <div style={{ position: 'relative', height: '500px', width: '100%' }}>
      <div id="map" style={{ height: '100%', width: '100%' }}></div>
      {selectedStation && (
        <button
          onClick={handlePaymentClick}
          style={{
            position: 'absolute',
            bottom: '20px',
            left: '20px',
            padding: '10px 20px',
            backgroundColor: '#28a745',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            zIndex: '1000', // Ensures the button is above the map
          }}
        >
          Get Directions (Payment Required)
        </button>
      )}
    </div>
  );
};

export default MapComponent;
