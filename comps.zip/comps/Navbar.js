import React from 'react';
// import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
// import Home from './Home';
// import Login from './Login';
// import Registration from './Registration';
// import Pricing from './Pricing';
// import Cafe from './Cafe';


const Navbar = () => {
    return (  
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                {/* <img src="D:\EV Link\ReactComps\ev-link\Images\LOGO2.webp"></img> */}
                <a className="navbar-brand" href="/">EV <span class="text-success">Link</span></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link active" aria-current="page" href="/">Home</a>
                    <a class="nav-link" href="/features">Features</a>
                    <a class="nav-link" href="/login">Login</a>
                    <a class="nav-link" href="/signUp">Sign-in</a>
                </div>
                </div>
            </div>
        </nav>
    //     <Router>
    //   <div>
    //     <nav>
    //       <ul>
    //         <li>
    //           <Link to="/">Home</Link>
    //         </li>
    //         {/* <li>
    //           <Link to="/find-stations">Find Stations</Link>
    //         </li>
    //         <li>
    //           <Link to="/plan-route">Plan Route</Link>
    //         </li>
    //         <li>
    //           <Link to="/monitor-charging">Monitor Charging</Link>
    //         </li> */}
    //         <li>
    //           <Link to="/login">Login</Link>
    //         </li>
    //         <li>
    //           <Link to="/register">Register</Link>
    //         </li>
    //         <li>
    //           <Link to="/pricing">Pricing</Link>
    //         </li>
    //         <li>
    //           <Link to="/cafes">Cafes</Link>
    //         </li>
    //       </ul>
    //     </nav>
    //     <Routes>
    //       <Route path="/" element={<Home />} />     
    //       <Route path="/login" element={<Login />} />
    //       <Route path="/register" element={<Registration />} />
    //       <Route path="/pricing" element={<Pricing />} />
    //       <Route path="/cafes" element={<Cafe />} />
    //     </Routes>
    //   </div>
    // </Router>
    );
}
 
export default Navbar;